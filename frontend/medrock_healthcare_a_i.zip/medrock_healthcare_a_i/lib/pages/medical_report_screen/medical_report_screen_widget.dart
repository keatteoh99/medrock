import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_pdf_viewer.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'medical_report_screen_model.dart';
export 'medical_report_screen_model.dart';

class MedicalReportScreenWidget extends StatefulWidget {
  const MedicalReportScreenWidget({
    super.key,
    required this.medicalReportUrl,
  });

  final String? medicalReportUrl;

  static String routeName = 'medical_report_screen';
  static String routePath = '/medicalReportScreen';

  @override
  State<MedicalReportScreenWidget> createState() =>
      _MedicalReportScreenWidgetState();
}

class _MedicalReportScreenWidgetState extends State<MedicalReportScreenWidget>
    with TickerProviderStateMixin {
  late MedicalReportScreenModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  LatLng? currentUserLocationValue;

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MedicalReportScreenModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      currentUserLocationValue =
          await getCurrentUserLocation(defaultLocation: LatLng(0.0, 0.0));
      // showProgressDots
      _model.aiResponding = false;
      _model.inputContent = '';
      _model.sessionId = random_data.randomString(
        12,
        12,
        true,
        false,
        false,
      );
      safeSetState(() {});
      FFAppState().Location = currentUserLocationValue;
      safeSetState(() {});
    });

    animationsMap.addAll({
      'floatingActionButtonOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 630.0.ms,
            duration: 420.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        floatingActionButton: Builder(
          builder: (context) => FloatingActionButton(
            onPressed: () async {
              await Share.share(
                widget!.medicalReportUrl!,
                sharePositionOrigin: getWidgetBoundingBox(context),
              );
            },
            backgroundColor: FlutterFlowTheme.of(context).primary,
            elevation: 8.0,
            child: Icon(
              Icons.ios_share,
              color: FlutterFlowTheme.of(context).info,
              size: 24.0,
            ),
          ).animateOnPageLoad(
              animationsMap['floatingActionButtonOnPageLoadAnimation']!),
        ),
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          iconTheme: IconThemeData(color: FlutterFlowTheme.of(context).primary),
          automaticallyImplyLeading: true,
          title: Text(
            'Medical Report',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  font: GoogleFonts.lexend(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineMedium.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineMedium.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 0.0,
        ),
        body: SafeArea(
          top: true,
          child: Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).primaryBackground,
              image: DecorationImage(
                fit: BoxFit.cover,
                image: Image.asset(
                  'assets/images/blur_bg@1x.png',
                ).image,
              ),
            ),
            child: FlutterFlowPdfViewer(
              networkPath: widget!.medicalReportUrl!,
              height: 300.0,
              horizontalScroll: false,
            ),
          ),
        ),
      ),
    );
  }
}
