import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_pdf_viewer.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'medical_report_screen_widget.dart' show MedicalReportScreenWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

class MedicalReportScreenModel
    extends FlutterFlowModel<MedicalReportScreenWidget> {
  ///  Local state fields for this page.

  String? inputContent = '';

  bool aiResponding = false;

  String? sessionId;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
