// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MedAIChatResponseBodyStruct extends BaseStruct {
  MedAIChatResponseBodyStruct({
    String? completion,
    ReturnControlStruct? returnControl,
    String? contentType,
  })  : _completion = completion,
        _returnControl = returnControl,
        _contentType = contentType;

  // "completion" field.
  String? _completion;
  String get completion => _completion ?? '';
  set completion(String? val) => _completion = val;

  bool hasCompletion() => _completion != null;

  // "returnControl" field.
  ReturnControlStruct? _returnControl;
  ReturnControlStruct get returnControl =>
      _returnControl ?? ReturnControlStruct();
  set returnControl(ReturnControlStruct? val) => _returnControl = val;

  void updateReturnControl(Function(ReturnControlStruct) updateFn) {
    updateFn(_returnControl ??= ReturnControlStruct());
  }

  bool hasReturnControl() => _returnControl != null;

  // "contentType" field.
  String? _contentType;
  String get contentType => _contentType ?? '';
  set contentType(String? val) => _contentType = val;

  bool hasContentType() => _contentType != null;

  static MedAIChatResponseBodyStruct fromMap(Map<String, dynamic> data) =>
      MedAIChatResponseBodyStruct(
        completion: data['completion'] as String?,
        returnControl: data['returnControl'] is ReturnControlStruct
            ? data['returnControl']
            : ReturnControlStruct.maybeFromMap(data['returnControl']),
        contentType: data['contentType'] as String?,
      );

  static MedAIChatResponseBodyStruct? maybeFromMap(dynamic data) => data is Map
      ? MedAIChatResponseBodyStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'completion': _completion,
        'returnControl': _returnControl?.toMap(),
        'contentType': _contentType,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'completion': serializeParam(
          _completion,
          ParamType.String,
        ),
        'returnControl': serializeParam(
          _returnControl,
          ParamType.DataStruct,
        ),
        'contentType': serializeParam(
          _contentType,
          ParamType.String,
        ),
      }.withoutNulls;

  static MedAIChatResponseBodyStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      MedAIChatResponseBodyStruct(
        completion: deserializeParam(
          data['completion'],
          ParamType.String,
          false,
        ),
        returnControl: deserializeStructParam(
          data['returnControl'],
          ParamType.DataStruct,
          false,
          structBuilder: ReturnControlStruct.fromSerializableMap,
        ),
        contentType: deserializeParam(
          data['contentType'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'MedAIChatResponseBodyStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is MedAIChatResponseBodyStruct &&
        completion == other.completion &&
        returnControl == other.returnControl &&
        contentType == other.contentType;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([completion, returnControl, contentType]);
}

MedAIChatResponseBodyStruct createMedAIChatResponseBodyStruct({
  String? completion,
  ReturnControlStruct? returnControl,
  String? contentType,
}) =>
    MedAIChatResponseBodyStruct(
      completion: completion,
      returnControl: returnControl ?? ReturnControlStruct(),
      contentType: contentType,
    );
