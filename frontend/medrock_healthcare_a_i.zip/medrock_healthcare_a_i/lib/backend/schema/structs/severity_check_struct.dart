// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SeverityCheckStruct extends BaseStruct {
  SeverityCheckStruct({
    String? severity,
    String? reason,
    String? recommendation,
    List<String>? possibleConditions,
    List<SymptomsStruct>? symptoms,
  })  : _severity = severity,
        _reason = reason,
        _recommendation = recommendation,
        _possibleConditions = possibleConditions,
        _symptoms = symptoms;

  // "severity" field.
  String? _severity;
  String get severity => _severity ?? '';
  set severity(String? val) => _severity = val;

  bool hasSeverity() => _severity != null;

  // "reason" field.
  String? _reason;
  String get reason => _reason ?? '';
  set reason(String? val) => _reason = val;

  bool hasReason() => _reason != null;

  // "recommendation" field.
  String? _recommendation;
  String get recommendation => _recommendation ?? '';
  set recommendation(String? val) => _recommendation = val;

  bool hasRecommendation() => _recommendation != null;

  // "possibleConditions" field.
  List<String>? _possibleConditions;
  List<String> get possibleConditions => _possibleConditions ?? const [];
  set possibleConditions(List<String>? val) => _possibleConditions = val;

  void updatePossibleConditions(Function(List<String>) updateFn) {
    updateFn(_possibleConditions ??= []);
  }

  bool hasPossibleConditions() => _possibleConditions != null;

  // "symptoms" field.
  List<SymptomsStruct>? _symptoms;
  List<SymptomsStruct> get symptoms => _symptoms ?? const [];
  set symptoms(List<SymptomsStruct>? val) => _symptoms = val;

  void updateSymptoms(Function(List<SymptomsStruct>) updateFn) {
    updateFn(_symptoms ??= []);
  }

  bool hasSymptoms() => _symptoms != null;

  static SeverityCheckStruct fromMap(Map<String, dynamic> data) =>
      SeverityCheckStruct(
        severity: data['severity'] as String?,
        reason: data['reason'] as String?,
        recommendation: data['recommendation'] as String?,
        possibleConditions: getDataList(data['possibleConditions']),
        symptoms: getStructList(
          data['symptoms'],
          SymptomsStruct.fromMap,
        ),
      );

  static SeverityCheckStruct? maybeFromMap(dynamic data) => data is Map
      ? SeverityCheckStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'severity': _severity,
        'reason': _reason,
        'recommendation': _recommendation,
        'possibleConditions': _possibleConditions,
        'symptoms': _symptoms?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'severity': serializeParam(
          _severity,
          ParamType.String,
        ),
        'reason': serializeParam(
          _reason,
          ParamType.String,
        ),
        'recommendation': serializeParam(
          _recommendation,
          ParamType.String,
        ),
        'possibleConditions': serializeParam(
          _possibleConditions,
          ParamType.String,
          isList: true,
        ),
        'symptoms': serializeParam(
          _symptoms,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static SeverityCheckStruct fromSerializableMap(Map<String, dynamic> data) =>
      SeverityCheckStruct(
        severity: deserializeParam(
          data['severity'],
          ParamType.String,
          false,
        ),
        reason: deserializeParam(
          data['reason'],
          ParamType.String,
          false,
        ),
        recommendation: deserializeParam(
          data['recommendation'],
          ParamType.String,
          false,
        ),
        possibleConditions: deserializeParam<String>(
          data['possibleConditions'],
          ParamType.String,
          true,
        ),
        symptoms: deserializeStructParam<SymptomsStruct>(
          data['symptoms'],
          ParamType.DataStruct,
          true,
          structBuilder: SymptomsStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'SeverityCheckStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is SeverityCheckStruct &&
        severity == other.severity &&
        reason == other.reason &&
        recommendation == other.recommendation &&
        listEquality.equals(possibleConditions, other.possibleConditions) &&
        listEquality.equals(symptoms, other.symptoms);
  }

  @override
  int get hashCode => const ListEquality()
      .hash([severity, reason, recommendation, possibleConditions, symptoms]);
}

SeverityCheckStruct createSeverityCheckStruct({
  String? severity,
  String? reason,
  String? recommendation,
}) =>
    SeverityCheckStruct(
      severity: severity,
      reason: reason,
      recommendation: recommendation,
    );
