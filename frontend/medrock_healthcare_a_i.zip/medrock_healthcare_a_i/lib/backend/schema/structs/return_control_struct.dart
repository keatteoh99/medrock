// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReturnControlStruct extends BaseStruct {
  ReturnControlStruct({
    String? invocationId,
    List<FunctionInvocationInputStruct>? invocationInputs,
  })  : _invocationId = invocationId,
        _invocationInputs = invocationInputs;

  // "invocationId" field.
  String? _invocationId;
  String get invocationId => _invocationId ?? '';
  set invocationId(String? val) => _invocationId = val;

  bool hasInvocationId() => _invocationId != null;

  // "invocationInputs" field.
  List<FunctionInvocationInputStruct>? _invocationInputs;
  List<FunctionInvocationInputStruct> get invocationInputs =>
      _invocationInputs ?? const [];
  set invocationInputs(List<FunctionInvocationInputStruct>? val) =>
      _invocationInputs = val;

  void updateInvocationInputs(
      Function(List<FunctionInvocationInputStruct>) updateFn) {
    updateFn(_invocationInputs ??= []);
  }

  bool hasInvocationInputs() => _invocationInputs != null;

  static ReturnControlStruct fromMap(Map<String, dynamic> data) =>
      ReturnControlStruct(
        invocationId: data['invocationId'] as String?,
        invocationInputs: getStructList(
          data['invocationInputs'],
          FunctionInvocationInputStruct.fromMap,
        ),
      );

  static ReturnControlStruct? maybeFromMap(dynamic data) => data is Map
      ? ReturnControlStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'invocationId': _invocationId,
        'invocationInputs': _invocationInputs?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'invocationId': serializeParam(
          _invocationId,
          ParamType.String,
        ),
        'invocationInputs': serializeParam(
          _invocationInputs,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static ReturnControlStruct fromSerializableMap(Map<String, dynamic> data) =>
      ReturnControlStruct(
        invocationId: deserializeParam(
          data['invocationId'],
          ParamType.String,
          false,
        ),
        invocationInputs: deserializeStructParam<FunctionInvocationInputStruct>(
          data['invocationInputs'],
          ParamType.DataStruct,
          true,
          structBuilder: FunctionInvocationInputStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'ReturnControlStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is ReturnControlStruct &&
        invocationId == other.invocationId &&
        listEquality.equals(invocationInputs, other.invocationInputs);
  }

  @override
  int get hashCode =>
      const ListEquality().hash([invocationId, invocationInputs]);
}

ReturnControlStruct createReturnControlStruct({
  String? invocationId,
}) =>
    ReturnControlStruct(
      invocationId: invocationId,
    );
