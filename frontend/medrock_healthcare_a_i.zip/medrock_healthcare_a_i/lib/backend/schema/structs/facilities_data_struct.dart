// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FacilitiesDataStruct extends BaseStruct {
  FacilitiesDataStruct({
    String? name,
    String? addresss,
    double? lat,
    double? lng,
    int? distanceM,
    String? phone,
    String? website,
    String? category,
    bool? openNow,
  })  : _name = name,
        _addresss = addresss,
        _lat = lat,
        _lng = lng,
        _distanceM = distanceM,
        _phone = phone,
        _website = website,
        _category = category,
        _openNow = openNow;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "addresss" field.
  String? _addresss;
  String get addresss => _addresss ?? '';
  set addresss(String? val) => _addresss = val;

  bool hasAddresss() => _addresss != null;

  // "lat" field.
  double? _lat;
  double get lat => _lat ?? 0.0;
  set lat(double? val) => _lat = val;

  void incrementLat(double amount) => lat = lat + amount;

  bool hasLat() => _lat != null;

  // "lng" field.
  double? _lng;
  double get lng => _lng ?? 0.0;
  set lng(double? val) => _lng = val;

  void incrementLng(double amount) => lng = lng + amount;

  bool hasLng() => _lng != null;

  // "distance_m" field.
  int? _distanceM;
  int get distanceM => _distanceM ?? 0;
  set distanceM(int? val) => _distanceM = val;

  void incrementDistanceM(int amount) => distanceM = distanceM + amount;

  bool hasDistanceM() => _distanceM != null;

  // "phone" field.
  String? _phone;
  String get phone => _phone ?? '';
  set phone(String? val) => _phone = val;

  bool hasPhone() => _phone != null;

  // "website" field.
  String? _website;
  String get website => _website ?? '';
  set website(String? val) => _website = val;

  bool hasWebsite() => _website != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  set category(String? val) => _category = val;

  bool hasCategory() => _category != null;

  // "open_now" field.
  bool? _openNow;
  bool get openNow => _openNow ?? false;
  set openNow(bool? val) => _openNow = val;

  bool hasOpenNow() => _openNow != null;

  static FacilitiesDataStruct fromMap(Map<String, dynamic> data) =>
      FacilitiesDataStruct(
        name: data['name'] as String?,
        addresss: data['addresss'] as String?,
        lat: castToType<double>(data['lat']),
        lng: castToType<double>(data['lng']),
        distanceM: castToType<int>(data['distance_m']),
        phone: data['phone'] as String?,
        website: data['website'] as String?,
        category: data['category'] as String?,
        openNow: data['open_now'] as bool?,
      );

  static FacilitiesDataStruct? maybeFromMap(dynamic data) => data is Map
      ? FacilitiesDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'addresss': _addresss,
        'lat': _lat,
        'lng': _lng,
        'distance_m': _distanceM,
        'phone': _phone,
        'website': _website,
        'category': _category,
        'open_now': _openNow,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'addresss': serializeParam(
          _addresss,
          ParamType.String,
        ),
        'lat': serializeParam(
          _lat,
          ParamType.double,
        ),
        'lng': serializeParam(
          _lng,
          ParamType.double,
        ),
        'distance_m': serializeParam(
          _distanceM,
          ParamType.int,
        ),
        'phone': serializeParam(
          _phone,
          ParamType.String,
        ),
        'website': serializeParam(
          _website,
          ParamType.String,
        ),
        'category': serializeParam(
          _category,
          ParamType.String,
        ),
        'open_now': serializeParam(
          _openNow,
          ParamType.bool,
        ),
      }.withoutNulls;

  static FacilitiesDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      FacilitiesDataStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        addresss: deserializeParam(
          data['addresss'],
          ParamType.String,
          false,
        ),
        lat: deserializeParam(
          data['lat'],
          ParamType.double,
          false,
        ),
        lng: deserializeParam(
          data['lng'],
          ParamType.double,
          false,
        ),
        distanceM: deserializeParam(
          data['distance_m'],
          ParamType.int,
          false,
        ),
        phone: deserializeParam(
          data['phone'],
          ParamType.String,
          false,
        ),
        website: deserializeParam(
          data['website'],
          ParamType.String,
          false,
        ),
        category: deserializeParam(
          data['category'],
          ParamType.String,
          false,
        ),
        openNow: deserializeParam(
          data['open_now'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'FacilitiesDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is FacilitiesDataStruct &&
        name == other.name &&
        addresss == other.addresss &&
        lat == other.lat &&
        lng == other.lng &&
        distanceM == other.distanceM &&
        phone == other.phone &&
        website == other.website &&
        category == other.category &&
        openNow == other.openNow;
  }

  @override
  int get hashCode => const ListEquality().hash(
      [name, addresss, lat, lng, distanceM, phone, website, category, openNow]);
}

FacilitiesDataStruct createFacilitiesDataStruct({
  String? name,
  String? addresss,
  double? lat,
  double? lng,
  int? distanceM,
  String? phone,
  String? website,
  String? category,
  bool? openNow,
}) =>
    FacilitiesDataStruct(
      name: name,
      addresss: addresss,
      lat: lat,
      lng: lng,
      distanceM: distanceM,
      phone: phone,
      website: website,
      category: category,
      openNow: openNow,
    );
