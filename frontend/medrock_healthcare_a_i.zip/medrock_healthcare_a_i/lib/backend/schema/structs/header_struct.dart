// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class HeaderStruct extends BaseStruct {
  HeaderStruct({
    String? contentType,
  }) : _contentType = contentType;

  // "contentType" field.
  String? _contentType;
  String get contentType => _contentType ?? '';
  set contentType(String? val) => _contentType = val;

  bool hasContentType() => _contentType != null;

  static HeaderStruct fromMap(Map<String, dynamic> data) => HeaderStruct(
        contentType: data['contentType'] as String?,
      );

  static HeaderStruct? maybeFromMap(dynamic data) =>
      data is Map ? HeaderStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'contentType': _contentType,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'contentType': serializeParam(
          _contentType,
          ParamType.String,
        ),
      }.withoutNulls;

  static HeaderStruct fromSerializableMap(Map<String, dynamic> data) =>
      HeaderStruct(
        contentType: deserializeParam(
          data['contentType'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'HeaderStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is HeaderStruct && contentType == other.contentType;
  }

  @override
  int get hashCode => const ListEquality().hash([contentType]);
}

HeaderStruct createHeaderStruct({
  String? contentType,
}) =>
    HeaderStruct(
      contentType: contentType,
    );
