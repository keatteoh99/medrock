// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SymptomsStruct extends BaseStruct {
  SymptomsStruct({
    String? name,
    String? severity,
    String? duration,
  })  : _name = name,
        _severity = severity,
        _duration = duration;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "severity" field.
  String? _severity;
  String get severity => _severity ?? '';
  set severity(String? val) => _severity = val;

  bool hasSeverity() => _severity != null;

  // "duration" field.
  String? _duration;
  String get duration => _duration ?? '';
  set duration(String? val) => _duration = val;

  bool hasDuration() => _duration != null;

  static SymptomsStruct fromMap(Map<String, dynamic> data) => SymptomsStruct(
        name: data['name'] as String?,
        severity: data['severity'] as String?,
        duration: data['duration'] as String?,
      );

  static SymptomsStruct? maybeFromMap(dynamic data) =>
      data is Map ? SymptomsStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'severity': _severity,
        'duration': _duration,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'severity': serializeParam(
          _severity,
          ParamType.String,
        ),
        'duration': serializeParam(
          _duration,
          ParamType.String,
        ),
      }.withoutNulls;

  static SymptomsStruct fromSerializableMap(Map<String, dynamic> data) =>
      SymptomsStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        severity: deserializeParam(
          data['severity'],
          ParamType.String,
          false,
        ),
        duration: deserializeParam(
          data['duration'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SymptomsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SymptomsStruct &&
        name == other.name &&
        severity == other.severity &&
        duration == other.duration;
  }

  @override
  int get hashCode => const ListEquality().hash([name, severity, duration]);
}

SymptomsStruct createSymptomsStruct({
  String? name,
  String? severity,
  String? duration,
}) =>
    SymptomsStruct(
      name: name,
      severity: severity,
      duration: duration,
    );
