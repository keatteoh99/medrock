// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FunctionInvocationInputStruct extends BaseStruct {
  FunctionInvocationInputStruct({
    String? actionGroup,
    String? actionInvocationType,
    String? agentId,
    String? function,
    List<FunctionInvocationInputParameterStruct>? parameters,
  })  : _actionGroup = actionGroup,
        _actionInvocationType = actionInvocationType,
        _agentId = agentId,
        _function = function,
        _parameters = parameters;

  // "actionGroup" field.
  String? _actionGroup;
  String get actionGroup => _actionGroup ?? '';
  set actionGroup(String? val) => _actionGroup = val;

  bool hasActionGroup() => _actionGroup != null;

  // "actionInvocationType" field.
  String? _actionInvocationType;
  String get actionInvocationType => _actionInvocationType ?? '';
  set actionInvocationType(String? val) => _actionInvocationType = val;

  bool hasActionInvocationType() => _actionInvocationType != null;

  // "agentId" field.
  String? _agentId;
  String get agentId => _agentId ?? '';
  set agentId(String? val) => _agentId = val;

  bool hasAgentId() => _agentId != null;

  // "function" field.
  String? _function;
  String get function => _function ?? '';
  set function(String? val) => _function = val;

  bool hasFunction() => _function != null;

  // "parameters" field.
  List<FunctionInvocationInputParameterStruct>? _parameters;
  List<FunctionInvocationInputParameterStruct> get parameters =>
      _parameters ?? const [];
  set parameters(List<FunctionInvocationInputParameterStruct>? val) =>
      _parameters = val;

  void updateParameters(
      Function(List<FunctionInvocationInputParameterStruct>) updateFn) {
    updateFn(_parameters ??= []);
  }

  bool hasParameters() => _parameters != null;

  static FunctionInvocationInputStruct fromMap(Map<String, dynamic> data) =>
      FunctionInvocationInputStruct(
        actionGroup: data['actionGroup'] as String?,
        actionInvocationType: data['actionInvocationType'] as String?,
        agentId: data['agentId'] as String?,
        function: data['function'] as String?,
        parameters: getStructList(
          data['parameters'],
          FunctionInvocationInputParameterStruct.fromMap,
        ),
      );

  static FunctionInvocationInputStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? FunctionInvocationInputStruct.fromMap(data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'actionGroup': _actionGroup,
        'actionInvocationType': _actionInvocationType,
        'agentId': _agentId,
        'function': _function,
        'parameters': _parameters?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'actionGroup': serializeParam(
          _actionGroup,
          ParamType.String,
        ),
        'actionInvocationType': serializeParam(
          _actionInvocationType,
          ParamType.String,
        ),
        'agentId': serializeParam(
          _agentId,
          ParamType.String,
        ),
        'function': serializeParam(
          _function,
          ParamType.String,
        ),
        'parameters': serializeParam(
          _parameters,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static FunctionInvocationInputStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      FunctionInvocationInputStruct(
        actionGroup: deserializeParam(
          data['actionGroup'],
          ParamType.String,
          false,
        ),
        actionInvocationType: deserializeParam(
          data['actionInvocationType'],
          ParamType.String,
          false,
        ),
        agentId: deserializeParam(
          data['agentId'],
          ParamType.String,
          false,
        ),
        function: deserializeParam(
          data['function'],
          ParamType.String,
          false,
        ),
        parameters:
            deserializeStructParam<FunctionInvocationInputParameterStruct>(
          data['parameters'],
          ParamType.DataStruct,
          true,
          structBuilder:
              FunctionInvocationInputParameterStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'FunctionInvocationInputStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is FunctionInvocationInputStruct &&
        actionGroup == other.actionGroup &&
        actionInvocationType == other.actionInvocationType &&
        agentId == other.agentId &&
        function == other.function &&
        listEquality.equals(parameters, other.parameters);
  }

  @override
  int get hashCode => const ListEquality()
      .hash([actionGroup, actionInvocationType, agentId, function, parameters]);
}

FunctionInvocationInputStruct createFunctionInvocationInputStruct({
  String? actionGroup,
  String? actionInvocationType,
  String? agentId,
  String? function,
}) =>
    FunctionInvocationInputStruct(
      actionGroup: actionGroup,
      actionInvocationType: actionInvocationType,
      agentId: agentId,
      function: function,
    );
