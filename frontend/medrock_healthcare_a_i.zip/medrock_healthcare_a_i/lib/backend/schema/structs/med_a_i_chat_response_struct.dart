// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MedAIChatResponseStruct extends BaseStruct {
  MedAIChatResponseStruct({
    int? statusCode,
    HeaderStruct? headers,
    MedAIChatResponseBodyStruct? body,
  })  : _statusCode = statusCode,
        _headers = headers,
        _body = body;

  // "statusCode" field.
  int? _statusCode;
  int get statusCode => _statusCode ?? 0;
  set statusCode(int? val) => _statusCode = val;

  void incrementStatusCode(int amount) => statusCode = statusCode + amount;

  bool hasStatusCode() => _statusCode != null;

  // "headers" field.
  HeaderStruct? _headers;
  HeaderStruct get headers => _headers ?? HeaderStruct();
  set headers(HeaderStruct? val) => _headers = val;

  void updateHeaders(Function(HeaderStruct) updateFn) {
    updateFn(_headers ??= HeaderStruct());
  }

  bool hasHeaders() => _headers != null;

  // "body" field.
  MedAIChatResponseBodyStruct? _body;
  MedAIChatResponseBodyStruct get body =>
      _body ?? MedAIChatResponseBodyStruct();
  set body(MedAIChatResponseBodyStruct? val) => _body = val;

  void updateBody(Function(MedAIChatResponseBodyStruct) updateFn) {
    updateFn(_body ??= MedAIChatResponseBodyStruct());
  }

  bool hasBody() => _body != null;

  static MedAIChatResponseStruct fromMap(Map<String, dynamic> data) =>
      MedAIChatResponseStruct(
        statusCode: castToType<int>(data['statusCode']),
        headers: data['headers'] is HeaderStruct
            ? data['headers']
            : HeaderStruct.maybeFromMap(data['headers']),
        body: data['body'] is MedAIChatResponseBodyStruct
            ? data['body']
            : MedAIChatResponseBodyStruct.maybeFromMap(data['body']),
      );

  static MedAIChatResponseStruct? maybeFromMap(dynamic data) => data is Map
      ? MedAIChatResponseStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'statusCode': _statusCode,
        'headers': _headers?.toMap(),
        'body': _body?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'statusCode': serializeParam(
          _statusCode,
          ParamType.int,
        ),
        'headers': serializeParam(
          _headers,
          ParamType.DataStruct,
        ),
        'body': serializeParam(
          _body,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static MedAIChatResponseStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      MedAIChatResponseStruct(
        statusCode: deserializeParam(
          data['statusCode'],
          ParamType.int,
          false,
        ),
        headers: deserializeStructParam(
          data['headers'],
          ParamType.DataStruct,
          false,
          structBuilder: HeaderStruct.fromSerializableMap,
        ),
        body: deserializeStructParam(
          data['body'],
          ParamType.DataStruct,
          false,
          structBuilder: MedAIChatResponseBodyStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'MedAIChatResponseStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is MedAIChatResponseStruct &&
        statusCode == other.statusCode &&
        headers == other.headers &&
        body == other.body;
  }

  @override
  int get hashCode => const ListEquality().hash([statusCode, headers, body]);
}

MedAIChatResponseStruct createMedAIChatResponseStruct({
  int? statusCode,
  HeaderStruct? headers,
  MedAIChatResponseBodyStruct? body,
}) =>
    MedAIChatResponseStruct(
      statusCode: statusCode,
      headers: headers ?? HeaderStruct(),
      body: body ?? MedAIChatResponseBodyStruct(),
    );
