// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatMessageStruct extends BaseStruct {
  ChatMessageStruct({
    ChatMessageType? type,
    String? completion,
    ReturnControlStruct? returnControl,
    ChatRole? role,
    List<FacilitiesDataStruct>? facilitiesData,
    SeverityCheckStruct? severityCheck,
  })  : _type = type,
        _completion = completion,
        _returnControl = returnControl,
        _role = role,
        _facilitiesData = facilitiesData,
        _severityCheck = severityCheck;

  // "type" field.
  ChatMessageType? _type;
  ChatMessageType? get type => _type;
  set type(ChatMessageType? val) => _type = val;

  bool hasType() => _type != null;

  // "completion" field.
  String? _completion;
  String get completion => _completion ?? '';
  set completion(String? val) => _completion = val;

  bool hasCompletion() => _completion != null;

  // "returnControl" field.
  ReturnControlStruct? _returnControl;
  ReturnControlStruct get returnControl =>
      _returnControl ?? ReturnControlStruct();
  set returnControl(ReturnControlStruct? val) => _returnControl = val;

  void updateReturnControl(Function(ReturnControlStruct) updateFn) {
    updateFn(_returnControl ??= ReturnControlStruct());
  }

  bool hasReturnControl() => _returnControl != null;

  // "role" field.
  ChatRole? _role;
  ChatRole? get role => _role;
  set role(ChatRole? val) => _role = val;

  bool hasRole() => _role != null;

  // "facilitiesData" field.
  List<FacilitiesDataStruct>? _facilitiesData;
  List<FacilitiesDataStruct> get facilitiesData => _facilitiesData ?? const [];
  set facilitiesData(List<FacilitiesDataStruct>? val) => _facilitiesData = val;

  void updateFacilitiesData(Function(List<FacilitiesDataStruct>) updateFn) {
    updateFn(_facilitiesData ??= []);
  }

  bool hasFacilitiesData() => _facilitiesData != null;

  // "severityCheck" field.
  SeverityCheckStruct? _severityCheck;
  SeverityCheckStruct get severityCheck =>
      _severityCheck ?? SeverityCheckStruct();
  set severityCheck(SeverityCheckStruct? val) => _severityCheck = val;

  void updateSeverityCheck(Function(SeverityCheckStruct) updateFn) {
    updateFn(_severityCheck ??= SeverityCheckStruct());
  }

  bool hasSeverityCheck() => _severityCheck != null;

  static ChatMessageStruct fromMap(Map<String, dynamic> data) =>
      ChatMessageStruct(
        type: data['type'] is ChatMessageType
            ? data['type']
            : deserializeEnum<ChatMessageType>(data['type']),
        completion: data['completion'] as String?,
        returnControl: data['returnControl'] is ReturnControlStruct
            ? data['returnControl']
            : ReturnControlStruct.maybeFromMap(data['returnControl']),
        role: data['role'] is ChatRole
            ? data['role']
            : deserializeEnum<ChatRole>(data['role']),
        facilitiesData: getStructList(
          data['facilitiesData'],
          FacilitiesDataStruct.fromMap,
        ),
        severityCheck: data['severityCheck'] is SeverityCheckStruct
            ? data['severityCheck']
            : SeverityCheckStruct.maybeFromMap(data['severityCheck']),
      );

  static ChatMessageStruct? maybeFromMap(dynamic data) => data is Map
      ? ChatMessageStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'type': _type?.serialize(),
        'completion': _completion,
        'returnControl': _returnControl?.toMap(),
        'role': _role?.serialize(),
        'facilitiesData': _facilitiesData?.map((e) => e.toMap()).toList(),
        'severityCheck': _severityCheck?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'type': serializeParam(
          _type,
          ParamType.Enum,
        ),
        'completion': serializeParam(
          _completion,
          ParamType.String,
        ),
        'returnControl': serializeParam(
          _returnControl,
          ParamType.DataStruct,
        ),
        'role': serializeParam(
          _role,
          ParamType.Enum,
        ),
        'facilitiesData': serializeParam(
          _facilitiesData,
          ParamType.DataStruct,
          isList: true,
        ),
        'severityCheck': serializeParam(
          _severityCheck,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static ChatMessageStruct fromSerializableMap(Map<String, dynamic> data) =>
      ChatMessageStruct(
        type: deserializeParam<ChatMessageType>(
          data['type'],
          ParamType.Enum,
          false,
        ),
        completion: deserializeParam(
          data['completion'],
          ParamType.String,
          false,
        ),
        returnControl: deserializeStructParam(
          data['returnControl'],
          ParamType.DataStruct,
          false,
          structBuilder: ReturnControlStruct.fromSerializableMap,
        ),
        role: deserializeParam<ChatRole>(
          data['role'],
          ParamType.Enum,
          false,
        ),
        facilitiesData: deserializeStructParam<FacilitiesDataStruct>(
          data['facilitiesData'],
          ParamType.DataStruct,
          true,
          structBuilder: FacilitiesDataStruct.fromSerializableMap,
        ),
        severityCheck: deserializeStructParam(
          data['severityCheck'],
          ParamType.DataStruct,
          false,
          structBuilder: SeverityCheckStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'ChatMessageStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is ChatMessageStruct &&
        type == other.type &&
        completion == other.completion &&
        returnControl == other.returnControl &&
        role == other.role &&
        listEquality.equals(facilitiesData, other.facilitiesData) &&
        severityCheck == other.severityCheck;
  }

  @override
  int get hashCode => const ListEquality().hash(
      [type, completion, returnControl, role, facilitiesData, severityCheck]);
}

ChatMessageStruct createChatMessageStruct({
  ChatMessageType? type,
  String? completion,
  ReturnControlStruct? returnControl,
  ChatRole? role,
  SeverityCheckStruct? severityCheck,
}) =>
    ChatMessageStruct(
      type: type,
      completion: completion,
      returnControl: returnControl ?? ReturnControlStruct(),
      role: role,
      severityCheck: severityCheck ?? SeverityCheckStruct(),
    );
