// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FunctionInvocationInputParameterStruct extends BaseStruct {
  FunctionInvocationInputParameterStruct({
    String? name,
    String? type,
    String? value,
  })  : _name = name,
        _type = type,
        _value = value;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  set type(String? val) => _type = val;

  bool hasType() => _type != null;

  // "value" field.
  String? _value;
  String get value => _value ?? '';
  set value(String? val) => _value = val;

  bool hasValue() => _value != null;

  static FunctionInvocationInputParameterStruct fromMap(
          Map<String, dynamic> data) =>
      FunctionInvocationInputParameterStruct(
        name: data['name'] as String?,
        type: data['type'] as String?,
        value: data['value'] as String?,
      );

  static FunctionInvocationInputParameterStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? FunctionInvocationInputParameterStruct.fromMap(
              data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'type': _type,
        'value': _value,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'type': serializeParam(
          _type,
          ParamType.String,
        ),
        'value': serializeParam(
          _value,
          ParamType.String,
        ),
      }.withoutNulls;

  static FunctionInvocationInputParameterStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      FunctionInvocationInputParameterStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        type: deserializeParam(
          data['type'],
          ParamType.String,
          false,
        ),
        value: deserializeParam(
          data['value'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'FunctionInvocationInputParameterStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is FunctionInvocationInputParameterStruct &&
        name == other.name &&
        type == other.type &&
        value == other.value;
  }

  @override
  int get hashCode => const ListEquality().hash([name, type, value]);
}

FunctionInvocationInputParameterStruct
    createFunctionInvocationInputParameterStruct({
  String? name,
  String? type,
  String? value,
}) =>
        FunctionInvocationInputParameterStruct(
          name: name,
          type: type,
          value: value,
        );
