import 'dart:convert';
import 'dart:typed_data';
import '../schema/structs/index.dart';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start MedAI API Group Code

class MedAIAPIGroup {
  static String getBaseUrl() =>
      'https://f7yz61rb65.execute-api.us-east-1.amazonaws.com/prod/';
  static Map<String, String> headers = {};
  static ChatCall chatCall = ChatCall();
  static GetNearbyFacilitiesCall getNearbyFacilitiesCall =
      GetNearbyFacilitiesCall();
  static ReturnFunctionResultCall returnFunctionResultCall =
      ReturnFunctionResultCall();
  static GetSeverityCall getSeverityCall = GetSeverityCall();
  static GetMedicalReportCall getMedicalReportCall = GetMedicalReportCall();
}

class ChatCall {
  Future<ApiCallResponse> call({
    String? sessionId = '',
    String? prompt = '',
  }) async {
    final baseUrl = MedAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "body": {
    "sessionId": "${escapeStringForJson(sessionId)}",
    "prompt": "${escapeStringForJson(prompt)}"
  }
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Chat',
      apiUrl: '${baseUrl}chat',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  int? resStatusCode(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.statusCode''',
      ));
  String? resCompletion(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.body.completion''',
      ));
  dynamic? returnControl(dynamic response) => getJsonField(
        response,
        r'''$.body.returnControl''',
      );
  String? invocationId(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.body.returnControl.invocationId''',
      ));
  dynamic? resBody(dynamic response) => getJsonField(
        response,
        r'''$.body''',
      );
  List? invocationInputs(dynamic response) => getJsonField(
        response,
        r'''$.body.returnControl.invocationInputs''',
        true,
      ) as List?;
  dynamic? functionInvocationInput(dynamic response) => getJsonField(
        response,
        r'''$.body.returnControl.invocationInputs[:].functionInvocationInput''',
      );
  String? invocationActionGroup(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.body.returnControl.invocationInputs[:].functionInvocationInput.actionGroup''',
      ));
  String? actionInvocationType(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.body.returnControl.invocationInputs[:].functionInvocationInput.actionInvocationType''',
      ));
  String? invocationAgentId(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.body.returnControl.invocationInputs[:].functionInvocationInput.agentId''',
      ));
  String? invocationFunction(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.body.returnControl.invocationInputs[:].functionInvocationInput.function''',
      ));
  List? invocationInputParameters(dynamic response) => getJsonField(
        response,
        r'''$.body.returnControl.invocationInputs[:].functionInvocationInput.parameters''',
        true,
      ) as List?;
  String? invocationInputParameterName(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.body.returnControl.invocationInputs[:].functionInvocationInput.parameters[:].name''',
      ));
  String? invocationInputParameterType(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.body.returnControl.invocationInputs[:].functionInvocationInput.parameters[:].type''',
      ));
  dynamic invocationInputParameterValue(dynamic response) => getJsonField(
        response,
        r'''$.body.returnControl.invocationInputs[:].functionInvocationInput.parameters[:].value''',
      );
}

class GetNearbyFacilitiesCall {
  Future<ApiCallResponse> call({
    double? latitude = 3.1390,
    double? longitude = 101.6869,
    String? category = 'hospital',
    int? radius = 5000,
  }) async {
    final baseUrl = MedAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "latitude": ${latitude},
  "longitude": ${longitude},
  "category": "${escapeStringForJson(category)}",
  "radius": ${radius}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Get Nearby Facilities',
      apiUrl: '${baseUrl}nearby-facilities',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  int? resStatusCode(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.statusCode''',
      ));
  List? resBody(dynamic response) => getJsonField(
        response,
        r'''$.body''',
        true,
      ) as List?;
}

class ReturnFunctionResultCall {
  Future<ApiCallResponse> call({
    String? sessionId = '',
    String? invocationId = '',
    String? actionGroup = '',
    String? function = '',
    String? invocationResult = '',
  }) async {
    final baseUrl = MedAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "body": {
    "sessionId": "${escapeStringForJson(sessionId)}",
    "returnControl": {
      "invocationId": "${escapeStringForJson(invocationId)}",
      "actionGroup": "${escapeStringForJson(actionGroup)}",
      "function": "${escapeStringForJson(function)}",
      "invocationResult": "${escapeStringForJson(invocationResult)}"
    }
  }
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Return Function Result',
      apiUrl: '${baseUrl}chat',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  int? resStatusCode(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.statusCode''',
      ));
  dynamic? resBody(dynamic response) => getJsonField(
        response,
        r'''$.body''',
      );
  String? resCompletion(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.body.completion''',
      ));
}

class GetSeverityCall {
  Future<ApiCallResponse> call({
    String? symptomText = '',
  }) async {
    final baseUrl = MedAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "symptom_text": "${escapeStringForJson(symptomText)}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Get Severity',
      apiUrl: '${baseUrl}analytics/severity',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  int? resStatusCode(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.statusCode''',
      ));
  dynamic? resBody(dynamic response) => getJsonField(
        response,
        r'''$.body''',
      );
  String? severity(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.body.severity''',
      ));
  String? reason(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.body.reason''',
      ));
  String? recommendation(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.body.recommendation''',
      ));
  List? symptoms(dynamic response) => getJsonField(
        response,
        r'''$.body.symptoms''',
        true,
      ) as List?;
  List<String>? possibleConditions(dynamic response) => (getJsonField(
        response,
        r'''$.body.possible_conditions''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
}

class GetMedicalReportCall {
  Future<ApiCallResponse> call({
    String? severity = '',
    String? reason = '',
    String? recommendation = '',
    dynamic? symptomsJson,
    List<String>? possibleConditionsList,
  }) async {
    final baseUrl = MedAIAPIGroup.getBaseUrl();
    final possibleConditions = _serializeList(possibleConditionsList);
    final symptoms = _serializeJson(symptomsJson, true);
    final ffApiRequestBody = '''
{
  "body": {
    "patient": {
      "patient_id": "1",
      "name": "Alex Doe",
      "age": 45,
      "gender": "Male",
      "medical_history": [
        "Hypertension",
        "Smoking History"
      ]
    },
    "severity": "${escapeStringForJson(severity)}",
    "reason": "${escapeStringForJson(reason)}",
    "recommendation": "${escapeStringForJson(recommendation)}",
    "symptoms": ${symptoms},
    "possible_conditions": ${possibleConditions}
  }
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Get Medical Report',
      apiUrl: '${baseUrl}/patients/1/report',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  int? resStatus(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.statusCode''',
      ));
  dynamic? resBody(dynamic response) => getJsonField(
        response,
        r'''$.body''',
      );
  String? reportURL(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.body.pdf_url''',
      ));
}

/// End MedAI API Group Code

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
