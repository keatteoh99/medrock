// Export pages
export '/a_i_chat_component/chat_ai_screen/chat_ai_screen_widget.dart'
    show ChatAiScreenWidget;
export '/pages/medical_report_screen/medical_report_screen_widget.dart'
    show MedicalReportScreenWidget;
