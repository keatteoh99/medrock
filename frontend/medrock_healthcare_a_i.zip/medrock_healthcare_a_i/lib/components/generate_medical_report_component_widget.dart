import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';
import 'generate_medical_report_component_model.dart';
export 'generate_medical_report_component_model.dart';

class GenerateMedicalReportComponentWidget extends StatefulWidget {
  const GenerateMedicalReportComponentWidget({
    super.key,
    required this.severityCheck,
  });

  final SeverityCheckStruct? severityCheck;

  @override
  State<GenerateMedicalReportComponentWidget> createState() =>
      _GenerateMedicalReportComponentWidgetState();
}

class _GenerateMedicalReportComponentWidgetState
    extends State<GenerateMedicalReportComponentWidget>
    with TickerProviderStateMixin {
  late GenerateMedicalReportComponentModel _model;

  final animationsMap = <String, AnimationInfo>{};

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenerateMedicalReportComponentModel());

    animationsMap.addAll({
      'progressBarOnPageLoadAnimation': AnimationInfo(
        loop: true,
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          RotateEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
    });
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        if (!_model.isGeneratingReport && !_model.reportGenerated)
          FFButtonWidget(
            onPressed: () async {
              _model.getMedicalReportResponse =
                  await MedAIAPIGroup.getMedicalReportCall.call(
                severity: widget!.severityCheck?.severity,
                reason: widget!.severityCheck?.reason,
                recommendation: widget!.severityCheck?.reason,
                symptomsJson: widget!.severityCheck?.symptoms
                    ?.map((e) => e.toMap())
                    .toList(),
                possibleConditionsList:
                    widget!.severityCheck?.possibleConditions,
              );

              _model.isGeneratingReport = true;
              safeSetState(() {});
              if (MedAIAPIGroup.getMedicalReportCall.resStatus(
                    (_model.getMedicalReportResponse?.jsonBody ?? ''),
                  ) ==
                  200) {
                _model.isGeneratingReport = false;
                _model.reportGenerated = true;
                safeSetState(() {});
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Report Generation Success',
                      style: TextStyle(
                        color: FlutterFlowTheme.of(context).primaryText,
                      ),
                    ),
                    duration: Duration(milliseconds: 4000),
                    backgroundColor: FlutterFlowTheme.of(context).secondary,
                  ),
                );
              } else {
                _model.isGeneratingReport = false;
                safeSetState(() {});
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      '',
                      style: TextStyle(
                        color: FlutterFlowTheme.of(context).primaryText,
                      ),
                    ),
                    duration: Duration(milliseconds: 4000),
                    backgroundColor: FlutterFlowTheme.of(context).error,
                  ),
                );
              }

              safeSetState(() {});
            },
            text: 'Generate Medical Report',
            options: FFButtonOptions(
              height: 40.0,
              padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
              iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
              color: FlutterFlowTheme.of(context).primary,
              textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                    font: GoogleFonts.lexend(
                      fontWeight:
                          FlutterFlowTheme.of(context).titleSmall.fontWeight,
                      fontStyle:
                          FlutterFlowTheme.of(context).titleSmall.fontStyle,
                    ),
                    color: Colors.white,
                    letterSpacing: 0.0,
                    fontWeight:
                        FlutterFlowTheme.of(context).titleSmall.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).titleSmall.fontStyle,
                  ),
              elevation: 0.0,
              borderRadius: BorderRadius.circular(8.0),
            ),
          ),
        if (_model.isGeneratingReport)
          CircularPercentIndicator(
            percent: 0.5,
            radius: 18.0,
            lineWidth: 8.0,
            animation: true,
            animateFromLastPercent: true,
            progressColor: FlutterFlowTheme.of(context).primary,
            backgroundColor: FlutterFlowTheme.of(context).accent4,
          ).animateOnPageLoad(animationsMap['progressBarOnPageLoadAnimation']!),
        if (_model.reportGenerated)
          FFButtonWidget(
            onPressed: () async {
              context.pushNamed(
                MedicalReportScreenWidget.routeName,
                queryParameters: {
                  'medicalReportUrl': serializeParam(
                    MedAIAPIGroup.getMedicalReportCall.reportURL(
                      (_model.getMedicalReportResponse?.jsonBody ?? ''),
                    ),
                    ParamType.String,
                  ),
                }.withoutNulls,
              );
            },
            text: 'View Report',
            options: FFButtonOptions(
              height: 40.0,
              padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
              iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
              color: FlutterFlowTheme.of(context).primary,
              textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                    font: GoogleFonts.lexend(
                      fontWeight:
                          FlutterFlowTheme.of(context).titleSmall.fontWeight,
                      fontStyle:
                          FlutterFlowTheme.of(context).titleSmall.fontStyle,
                    ),
                    color: Colors.white,
                    letterSpacing: 0.0,
                    fontWeight:
                        FlutterFlowTheme.of(context).titleSmall.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).titleSmall.fontStyle,
                  ),
              elevation: 0.0,
              borderRadius: BorderRadius.circular(8.0),
            ),
          ),
      ],
    );
  }
}
