import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';

dynamic saveChatHistory(
  List<String>? chatHistory,
  String newChat,
) {
  // If chatHistory isn't a list, make it a list and then add newChat
  // if (chatHistory is List) {
  //   chatHistory!.add(newChat);
  //   return chatHistory;
  // } else {
  //   return [newChat];
  // }
  if (chatHistory == null) {
    chatHistory = [];
  }

  chatHistory.add(newChat);
  return chatHistory;
}

dynamic convertToJSON(String prompt) {
  // take the prompt and return a JSON with form [{"role": "user", "content": prompt}]
  return json.decode('{"role": "user", "content": "$prompt"}');
}

double getLatitudeFromLatLng(LatLng? latLng) {
  // Takes LatLng and return latitude as double
  return latLng?.latitude ?? 0.0;
}

double getLongitudeFromLatLng(LatLng? latLng) {
  // Takes LatLng and return latitude as double
  return latLng?.longitude ?? 0.0;
}

String getGoogleMapURLFromCoords(
  double latitude,
  String longitude,
) {
  return 'https://www.google.com/maps/@$latitude,$longitude,15z'; // Google Maps URL
}
