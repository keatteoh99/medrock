import '/a_i_chat_component/empty_list/empty_list_widget.dart';
import '/a_i_chat_component/facilities_list/facilities_list_widget.dart';
import '/a_i_chat_component/writing_indicator/writing_indicator_widget.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/components/severity_card_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'ai_chat_component_model.dart';
export 'ai_chat_component_model.dart';

class AiChatComponentWidget extends StatefulWidget {
  const AiChatComponentWidget({
    super.key,
    required this.sessionId,
  });

  final String? sessionId;

  @override
  State<AiChatComponentWidget> createState() => _AiChatComponentWidgetState();
}

class _AiChatComponentWidgetState extends State<AiChatComponentWidget> {
  late AiChatComponentModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AiChatComponentModel());

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Container(
        width: double.infinity,
        height: double.infinity,
        constraints: BoxConstraints(
          maxWidth: 770.0,
        ),
        decoration: BoxDecoration(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Expanded(
              child: Align(
                alignment: AlignmentDirectional(0.0, -1.0),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    if (responsiveVisibility(
                      context: context,
                      phone: false,
                      tablet: false,
                    ))
                      Container(
                        width: 100.0,
                        height: 24.0,
                        decoration: BoxDecoration(),
                      ),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            12.0, 12.0, 12.0, 0.0),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12.0),
                          child: BackdropFilter(
                            filter: ImageFilter.blur(
                              sigmaX: 5.0,
                              sigmaY: 4.0,
                            ),
                            child: Container(
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context).accent4,
                                borderRadius: BorderRadius.circular(12.0),
                                border: Border.all(
                                  color: FlutterFlowTheme.of(context).alternate,
                                  width: 1.0,
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Align(
                                      alignment:
                                          AlignmentDirectional(0.0, -1.0),
                                      child: Builder(
                                        builder: (context) {
                                          final chat =
                                              _model.chatHistory.toList();
                                          if (chat.isEmpty) {
                                            return Container(
                                              width: double.infinity,
                                              child: EmptyListWidget(),
                                            );
                                          }

                                          return ListView.builder(
                                            padding: EdgeInsets.fromLTRB(
                                              0,
                                              16.0,
                                              0,
                                              16.0,
                                            ),
                                            scrollDirection: Axis.vertical,
                                            itemCount: chat.length,
                                            itemBuilder: (context, chatIndex) {
                                              final chatItem = chat[chatIndex];
                                              return Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        12.0, 12.0, 12.0, 0.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    if ((chatItem.role ==
                                                            ChatRole
                                                                .assistant) &&
                                                        ((chatItem.type ==
                                                                ChatMessageType
                                                                    .text) ||
                                                            (chatItem.type ==
                                                                ChatMessageType
                                                                    .functionCall)))
                                                      Row(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        children: [
                                                          Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Container(
                                                                constraints:
                                                                    BoxConstraints(
                                                                  maxWidth: () {
                                                                    if (MediaQuery.sizeOf(context)
                                                                            .width >=
                                                                        1170.0) {
                                                                      return 700.0;
                                                                    } else if (MediaQuery.sizeOf(context)
                                                                            .width <=
                                                                        470.0) {
                                                                      return 330.0;
                                                                    } else {
                                                                      return 530.0;
                                                                    }
                                                                  }(),
                                                                ),
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .accent1,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .only(
                                                                    bottomLeft:
                                                                        Radius.circular(
                                                                            0.0),
                                                                    bottomRight:
                                                                        Radius.circular(
                                                                            12.0),
                                                                    topLeft: Radius
                                                                        .circular(
                                                                            12.0),
                                                                    topRight: Radius
                                                                        .circular(
                                                                            12.0),
                                                                  ),
                                                                  border: Border
                                                                      .all(
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .primary,
                                                                    width: 2.0,
                                                                  ),
                                                                ),
                                                                child: Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          12.0,
                                                                          8.0,
                                                                          12.0,
                                                                          8.0),
                                                                  child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      SelectionArea(
                                                                          child:
                                                                              AutoSizeText(
                                                                        valueOrDefault<
                                                                            String>(
                                                                          _model
                                                                              .chatHistory
                                                                              .elementAtOrNull(chatIndex)
                                                                              ?.completion,
                                                                          'No Message',
                                                                        ),
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              font: GoogleFonts.inter(
                                                                                fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                              ),
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                              lineHeight: 1.5,
                                                                            ),
                                                                      )),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            2.0,
                                                                            0.0,
                                                                            0.0),
                                                                child: InkWell(
                                                                  splashColor:
                                                                      Colors
                                                                          .transparent,
                                                                  focusColor: Colors
                                                                      .transparent,
                                                                  hoverColor: Colors
                                                                      .transparent,
                                                                  highlightColor:
                                                                      Colors
                                                                          .transparent,
                                                                  onTap:
                                                                      () async {
                                                                    await Clipboard.setData(ClipboardData(
                                                                        text: _model
                                                                            .chatHistory
                                                                            .elementAtOrNull(chatIndex)!
                                                                            .completion));
                                                                    ScaffoldMessenger.of(
                                                                            context)
                                                                        .showSnackBar(
                                                                      SnackBar(
                                                                        content:
                                                                            Text(
                                                                          'Response copied to clipboard.',
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodyMedium
                                                                              .override(
                                                                                font: GoogleFonts.inter(
                                                                                  fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                ),
                                                                                color: FlutterFlowTheme.of(context).info,
                                                                                fontSize: 12.0,
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                              ),
                                                                        ),
                                                                        duration:
                                                                            Duration(milliseconds: 2000),
                                                                        backgroundColor:
                                                                            FlutterFlowTheme.of(context).primary,
                                                                      ),
                                                                    );
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    decoration:
                                                                        BoxDecoration(),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          4.0,
                                                                          12.0,
                                                                          4.0),
                                                                      child:
                                                                          Row(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        children: [
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                4.0,
                                                                                0.0,
                                                                                0.0,
                                                                                0.0),
                                                                            child:
                                                                                Icon(
                                                                              Icons.content_copy,
                                                                              color: FlutterFlowTheme.of(context).secondaryText,
                                                                              size: 12.0,
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                4.0,
                                                                                0.0,
                                                                                0.0,
                                                                                0.0),
                                                                            child:
                                                                                Text(
                                                                              'Copy response',
                                                                              style: FlutterFlowTheme.of(context).labelSmall.override(
                                                                                    font: GoogleFonts.inter(
                                                                                      fontWeight: FlutterFlowTheme.of(context).labelSmall.fontWeight,
                                                                                      fontStyle: FlutterFlowTheme.of(context).labelSmall.fontStyle,
                                                                                    ),
                                                                                    letterSpacing: 0.0,
                                                                                    fontWeight: FlutterFlowTheme.of(context).labelSmall.fontWeight,
                                                                                    fontStyle: FlutterFlowTheme.of(context).labelSmall.fontStyle,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    if (chatItem.facilitiesData
                                                        .isNotEmpty)
                                                      wrapWithModel(
                                                        model: _model
                                                            .facilitiesListModels
                                                            .getModel(
                                                          chatIndex.toString(),
                                                          chatIndex,
                                                        ),
                                                        updateCallback: () =>
                                                            safeSetState(() {}),
                                                        child:
                                                            FacilitiesListWidget(
                                                          key: Key(
                                                            'Key3yf_${chatIndex.toString()}',
                                                          ),
                                                          text: valueOrDefault<
                                                              String>(
                                                            _model.chatHistory
                                                                .elementAtOrNull(
                                                                    chatIndex)
                                                                ?.completion,
                                                            'No Message',
                                                          ),
                                                          role: chatItem.role,
                                                          facility: chatItem
                                                              .facilitiesData,
                                                        ),
                                                      ),
                                                    if (chatItem.role ==
                                                        ChatRole.user)
                                                      Row(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: [
                                                          Container(
                                                            constraints:
                                                                BoxConstraints(
                                                              maxWidth: () {
                                                                if (MediaQuery.sizeOf(
                                                                            context)
                                                                        .width >=
                                                                    1170.0) {
                                                                  return 700.0;
                                                                } else if (MediaQuery.sizeOf(
                                                                            context)
                                                                        .width <=
                                                                    470.0) {
                                                                  return 330.0;
                                                                } else {
                                                                  return 530.0;
                                                                }
                                                              }(),
                                                            ),
                                                            decoration:
                                                                BoxDecoration(
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .primaryBackground,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .only(
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                        12.0),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                        0.0),
                                                                topLeft: Radius
                                                                    .circular(
                                                                        12.0),
                                                                topRight: Radius
                                                                    .circular(
                                                                        12.0),
                                                              ),
                                                              border:
                                                                  Border.all(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .alternate,
                                                              ),
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          12.0,
                                                                          8.0,
                                                                          12.0,
                                                                          8.0),
                                                              child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text(
                                                                    chatItem
                                                                        .completion,
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          font:
                                                                              GoogleFonts.inter(
                                                                            fontWeight:
                                                                                FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                            fontStyle:
                                                                                FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                          ),
                                                                          letterSpacing:
                                                                              0.0,
                                                                          fontWeight: FlutterFlowTheme.of(context)
                                                                              .bodyMedium
                                                                              .fontWeight,
                                                                          fontStyle: FlutterFlowTheme.of(context)
                                                                              .bodyMedium
                                                                              .fontStyle,
                                                                        ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    if ((chatItem
                                                                .severityCheck !=
                                                            null) &&
                                                        (chatItem.type ==
                                                            ChatMessageType
                                                                .severityFnResult))
                                                      wrapWithModel(
                                                        model: _model
                                                            .severityCardModels
                                                            .getModel(
                                                          chatIndex.toString(),
                                                          chatIndex,
                                                        ),
                                                        updateCallback: () =>
                                                            safeSetState(() {}),
                                                        child:
                                                            SeverityCardWidget(
                                                          key: Key(
                                                            'Keyv8h_${chatIndex.toString()}',
                                                          ),
                                                          severityCheck: chatItem
                                                              .severityCheck,
                                                        ),
                                                      ),
                                                  ],
                                                ),
                                              );
                                            },
                                            controller:
                                                _model.listViewController,
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                  if (_model.aiResponding == true)
                                    Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        wrapWithModel(
                                          model: _model.writingIndicatorModel,
                                          updateCallback: () =>
                                              safeSetState(() {}),
                                          child: WritingIndicatorWidget(),
                                        ),
                                      ],
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(12.0),
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                  boxShadow: [
                    BoxShadow(
                      blurRadius: 3.0,
                      color: Color(0x33000000),
                      offset: Offset(
                        0.0,
                        1.0,
                      ),
                    )
                  ],
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: Stack(
                  children: [
                    Container(
                      width: double.infinity,
                      child: TextFormField(
                        controller: _model.textController,
                        focusNode: _model.textFieldFocusNode,
                        autofocus: true,
                        textCapitalization: TextCapitalization.sentences,
                        obscureText: false,
                        decoration: InputDecoration(
                          hintText: 'Type something...',
                          hintStyle:
                              FlutterFlowTheme.of(context).labelLarge.override(
                                    font: GoogleFonts.inter(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .labelLarge
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .labelLarge
                                          .fontStyle,
                                    ),
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .fontStyle,
                                  ),
                          errorStyle:
                              FlutterFlowTheme.of(context).bodyLarge.override(
                                    font: GoogleFonts.inter(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .bodyLarge
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyLarge
                                          .fontStyle,
                                    ),
                                    color: FlutterFlowTheme.of(context).error,
                                    fontSize: 12.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .bodyLarge
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .bodyLarge
                                        .fontStyle,
                                  ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).alternate,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(12.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).primary,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(12.0),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).error,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(12.0),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).error,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(12.0),
                          ),
                          contentPadding: EdgeInsetsDirectional.fromSTEB(
                              16.0, 24.0, 70.0, 24.0),
                        ),
                        style: FlutterFlowTheme.of(context).bodyLarge.override(
                              font: GoogleFonts.inter(
                                fontWeight: FlutterFlowTheme.of(context)
                                    .bodyLarge
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .bodyLarge
                                    .fontStyle,
                              ),
                              letterSpacing: 0.0,
                              fontWeight: FlutterFlowTheme.of(context)
                                  .bodyLarge
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .bodyLarge
                                  .fontStyle,
                            ),
                        maxLines: 8,
                        minLines: 1,
                        keyboardType: TextInputType.multiline,
                        cursorColor: FlutterFlowTheme.of(context).primary,
                        validator:
                            _model.textControllerValidator.asValidator(context),
                        inputFormatters: [
                          if (!isAndroid && !isiOS)
                            TextInputFormatter.withFunction(
                                (oldValue, newValue) {
                              return TextEditingValue(
                                selection: newValue.selection,
                                text: newValue.text.toCapitalization(
                                    TextCapitalization.sentences),
                              );
                            }),
                        ],
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(1.0, 0.0),
                      child: FlutterFlowIconButton(
                        borderColor: Colors.transparent,
                        borderRadius: 30.0,
                        borderWidth: 1.0,
                        buttonSize: 60.0,
                        icon: Icon(
                          Icons.send_rounded,
                          color: FlutterFlowTheme.of(context).primary,
                          size: 30.0,
                        ),
                        showLoadingIndicator: true,
                        onPressed: () async {
                          // addToChat_aiTyping
                          _model.aiResponding = true;
                          _model.inputContent = _model.textController.text;
                          _model.addToChatHistory(ChatMessageStruct(
                            role: ChatRole.user,
                            type: ChatMessageType.text,
                            completion: _model.inputContent,
                          ));
                          safeSetState(() {});
                          safeSetState(() {
                            _model.textController?.clear();
                          });
                          // The "chatHistory" is the generated JSON -- we send the whole chat history to AI in order for it to understand context.
                          // Call Agent
                          _model.agentResponse =
                              await MedAIAPIGroup.chatCall.call(
                            sessionId: widget!.sessionId,
                            prompt: _model.inputContent,
                          );

                          if (MedAIAPIGroup.chatCall.resStatusCode(
                                (_model.agentResponse?.jsonBody ?? ''),
                              ) ==
                              200) {
                            _model.aiResponding = false;
                            safeSetState(() {});
                            if (MedAIAPIGroup.chatCall.returnControl(
                                  (_model.agentResponse?.jsonBody ?? ''),
                                ) ==
                                null) {
                              _model.addToChatHistory(ChatMessageStruct(
                                type: ChatMessageType.text,
                                completion:
                                    MedAIAPIGroup.chatCall.resCompletion(
                                  (_model.agentResponse?.jsonBody ?? ''),
                                ),
                                role: ChatRole.assistant,
                              ));
                              safeSetState(() {});
                            } else {
                              if ((MedAIAPIGroup.chatCall.invocationInputs(
                                            (_model.agentResponse?.jsonBody ??
                                                ''),
                                          ) !=
                                          null &&
                                      (MedAIAPIGroup.chatCall.invocationInputs(
                                        (_model.agentResponse?.jsonBody ?? ''),
                                      ))!
                                          .isNotEmpty) ==
                                  true) {
                                // Add Tool Call to Chat History
                                _model.addToChatHistory(ChatMessageStruct(
                                  type: ChatMessageType.functionCall,
                                  completion:
                                      'Calling ${MedAIAPIGroup.chatCall.invocationFunction(
                                    (_model.agentResponse?.jsonBody ?? ''),
                                  )} 🛠️',
                                  role: ChatRole.assistant,
                                ));
                                safeSetState(() {});
                                if (MedAIAPIGroup.chatCall.invocationFunction(
                                      (_model.agentResponse?.jsonBody ?? ''),
                                    ) ==
                                    'get_nearby_facilities') {
                                  _model.getFacilitiesApiResponse =
                                      await MedAIAPIGroup
                                          .getNearbyFacilitiesCall
                                          .call(
                                    latitude: 3.12313,
                                    longitude: 101.6869,
                                    radius: 5000,
                                    category: getJsonField(
                                      (_model.agentResponse?.jsonBody ?? ''),
                                      r'''$.body.returnControl.invocationInputs[0].functionInvocationInput.parameters[?(@.name=="category")].value''',
                                    ).toString(),
                                  );

                                  if ((_model.getFacilitiesApiResponse
                                              ?.statusCode ??
                                          200) ==
                                      200) {
                                    // Map Facilities List
                                    _model.addToChatHistory(ChatMessageStruct(
                                      role: ChatRole.assistant,
                                      type: ChatMessageType.faciltiesFnResult,
                                      facilitiesData: MedAIAPIGroup
                                          .getNearbyFacilitiesCall
                                          .resBody(
                                            (_model.getFacilitiesApiResponse
                                                    ?.jsonBody ??
                                                ''),
                                          )
                                          ?.map((e) =>
                                              FacilitiesDataStruct.maybeFromMap(
                                                  e))
                                          .withoutNulls
                                          .toList(),
                                      completion:
                                          'Here is a list of facilities nearby:',
                                    ));
                                    safeSetState(() {});
                                    // Confirm Function Invoked
                                    _model.returnInvocationResponse =
                                        await MedAIAPIGroup
                                            .returnFunctionResultCall
                                            .call(
                                      sessionId: widget!.sessionId,
                                      invocationId:
                                          MedAIAPIGroup.chatCall.invocationId(
                                        (_model.agentResponse?.jsonBody ?? ''),
                                      ),
                                      actionGroup: MedAIAPIGroup.chatCall
                                          .invocationActionGroup(
                                        (_model.agentResponse?.jsonBody ?? ''),
                                      ),
                                      function: MedAIAPIGroup.chatCall
                                          .invocationFunction(
                                        (_model.agentResponse?.jsonBody ?? ''),
                                      ),
                                      invocationResult: (_model
                                                  .getFacilitiesApiResponse
                                                  ?.jsonBody ??
                                              '')
                                          .toString(),
                                    );

                                    if ((_model.returnInvocationResponse
                                                ?.statusCode ??
                                            200) ==
                                        200) {
                                    } else {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                          content: Text(
                                            MedAIAPIGroup
                                                .returnFunctionResultCall
                                                .resBody(
                                                  (_model.returnInvocationResponse
                                                          ?.jsonBody ??
                                                      ''),
                                                )
                                                .toString(),
                                            style: TextStyle(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryText,
                                            ),
                                          ),
                                          duration:
                                              Duration(milliseconds: 4000),
                                          backgroundColor:
                                              FlutterFlowTheme.of(context)
                                                  .tertiary,
                                        ),
                                      );
                                    }
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          'Your API call failed',
                                          style: TextStyle(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryText,
                                          ),
                                        ),
                                        duration: Duration(milliseconds: 4000),
                                        backgroundColor:
                                            FlutterFlowTheme.of(context)
                                                .secondary,
                                      ),
                                    );
                                  }
                                } else if (MedAIAPIGroup.chatCall
                                        .invocationFunction(
                                      (_model.agentResponse?.jsonBody ?? ''),
                                    ) ==
                                    'get_severity') {
                                  _model.severityAPIResponse =
                                      await MedAIAPIGroup.getSeverityCall.call(
                                    symptomText: getJsonField(
                                      (_model.agentResponse?.jsonBody ?? ''),
                                      r'''$.body.returnControl.invocationInputs[0].functionInvocationInput.parameters[?(@.name=="symptom_text")].value''',
                                    ).toString(),
                                  );

                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'BODY: ${getJsonField(
                                          (_model.agentResponse?.jsonBody ??
                                              ''),
                                          r'''$.body.returnControl.invocationInputs[0].functionInvocationInput.parameters[?(@.name=="symptom_text")].value''',
                                        ).toString()}',
                                        style: TextStyle(
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                        ),
                                      ),
                                      duration: Duration(milliseconds: 4000),
                                      backgroundColor:
                                          FlutterFlowTheme.of(context)
                                              .secondary,
                                    ),
                                  );
                                  if (MedAIAPIGroup.getSeverityCall
                                          .resStatusCode(
                                        (_model.severityAPIResponse?.jsonBody ??
                                            ''),
                                      ) ==
                                      200) {
                                    _model.addToChatHistory(ChatMessageStruct(
                                      type: ChatMessageType.severityFnResult,
                                      role: ChatRole.assistant,
                                      severityCheck: SeverityCheckStruct(
                                        severity: MedAIAPIGroup.getSeverityCall
                                            .severity(
                                          (_model.severityAPIResponse
                                                  ?.jsonBody ??
                                              ''),
                                        ),
                                        reason: MedAIAPIGroup.getSeverityCall
                                            .reason(
                                          (_model.severityAPIResponse
                                                  ?.jsonBody ??
                                              ''),
                                        ),
                                        recommendation: MedAIAPIGroup
                                            .getSeverityCall
                                            .recommendation(
                                          (_model.severityAPIResponse
                                                  ?.jsonBody ??
                                              ''),
                                        ),
                                        possibleConditions: MedAIAPIGroup
                                            .getSeverityCall
                                            .possibleConditions(
                                          (_model.severityAPIResponse
                                                  ?.jsonBody ??
                                              ''),
                                        ),
                                        symptoms: MedAIAPIGroup.getSeverityCall
                                            .symptoms(
                                              (_model.severityAPIResponse
                                                      ?.jsonBody ??
                                                  ''),
                                            )
                                            ?.map((e) =>
                                                SymptomsStruct.maybeFromMap(e))
                                            .withoutNulls
                                            .toList(),
                                      ),
                                    ));
                                    safeSetState(() {});
                                    // Confirm Function Invoked
                                    _model.returnInvocationResponseSevCheck =
                                        await MedAIAPIGroup
                                            .returnFunctionResultCall
                                            .call(
                                      sessionId: widget!.sessionId,
                                      invocationId:
                                          MedAIAPIGroup.chatCall.invocationId(
                                        (_model.agentResponse?.jsonBody ?? ''),
                                      ),
                                      actionGroup: MedAIAPIGroup.chatCall
                                          .invocationActionGroup(
                                        (_model.agentResponse?.jsonBody ?? ''),
                                      ),
                                      function: MedAIAPIGroup.chatCall
                                          .invocationFunction(
                                        (_model.agentResponse?.jsonBody ?? ''),
                                      ),
                                      invocationResult: (_model
                                                  .severityAPIResponse
                                                  ?.jsonBody ??
                                              '')
                                          .toString(),
                                    );

                                    if ((_model.returnInvocationResponseSevCheck
                                                ?.statusCode ??
                                            200) ==
                                        200) {
                                      // Add  Assistant Respond after Responding with Severity Assessment
                                      _model.addToChatHistory(ChatMessageStruct(
                                        type: ChatMessageType.text,
                                        completion: MedAIAPIGroup
                                            .returnFunctionResultCall
                                            .resCompletion(
                                          (_model.returnInvocationResponseSevCheck
                                                  ?.jsonBody ??
                                              ''),
                                        ),
                                        role: ChatRole.assistant,
                                      ));
                                      safeSetState(() {});
                                    } else {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                          content: Text(
                                            MedAIAPIGroup
                                                .returnFunctionResultCall
                                                .resBody(
                                                  (_model.returnInvocationResponseSevCheck
                                                          ?.jsonBody ??
                                                      ''),
                                                )
                                                .toString(),
                                            style: TextStyle(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryText,
                                            ),
                                          ),
                                          duration:
                                              Duration(milliseconds: 4000),
                                          backgroundColor:
                                              FlutterFlowTheme.of(context)
                                                  .tertiary,
                                        ),
                                      );
                                    }
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          'Your API call failed',
                                          style: TextStyle(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryText,
                                          ),
                                        ),
                                        duration: Duration(milliseconds: 4000),
                                        backgroundColor:
                                            FlutterFlowTheme.of(context)
                                                .secondary,
                                      ),
                                    );
                                  }
                                }
                              }
                            }
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  'Your API Call Failed!',
                                  style: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .override(
                                        font: GoogleFonts.lexend(
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontStyle,
                                        ),
                                        color:
                                            FlutterFlowTheme.of(context).info,
                                        letterSpacing: 0.0,
                                        fontWeight: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .fontWeight,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .fontStyle,
                                      ),
                                ),
                                duration: Duration(milliseconds: 4000),
                                backgroundColor:
                                    FlutterFlowTheme.of(context).error,
                              ),
                            );
                            _model.aiResponding = false;
                            safeSetState(() {});
                          }

                          await Future.delayed(
                            Duration(
                              milliseconds: 800,
                            ),
                          );
                          await _model.listViewController?.animateTo(
                            _model.listViewController!.position.maxScrollExtent,
                            duration: Duration(milliseconds: 100),
                            curve: Curves.ease,
                          );

                          safeSetState(() {});
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (responsiveVisibility(
              context: context,
              phone: false,
              tablet: false,
            ))
              Container(
                width: 100.0,
                height: 60.0,
                decoration: BoxDecoration(),
              ),
          ],
        ),
      ),
    );
  }
}
