import '/a_i_chat_component/empty_list/empty_list_widget.dart';
import '/a_i_chat_component/facilities_list/facilities_list_widget.dart';
import '/a_i_chat_component/writing_indicator/writing_indicator_widget.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/components/severity_card_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'ai_chat_component_widget.dart' show AiChatComponentWidget;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AiChatComponentModel extends FlutterFlowModel<AiChatComponentWidget> {
  ///  Local state fields for this component.

  List<ChatMessageStruct> chatHistory = [];
  void addToChatHistory(ChatMessageStruct item) => chatHistory.add(item);
  void removeFromChatHistory(ChatMessageStruct item) =>
      chatHistory.remove(item);
  void removeAtIndexFromChatHistory(int index) => chatHistory.removeAt(index);
  void insertAtIndexInChatHistory(int index, ChatMessageStruct item) =>
      chatHistory.insert(index, item);
  void updateChatHistoryAtIndex(
          int index, Function(ChatMessageStruct) updateFn) =>
      chatHistory[index] = updateFn(chatHistory[index]);

  bool aiResponding = false;

  String? inputContent;

  /// sessionId
  String sessionId = '';

  ///  State fields for stateful widgets in this component.

  // State field(s) for ListView widget.
  ScrollController? listViewController;
  // Models for facilitiesList dynamic component.
  late FlutterFlowDynamicModels<FacilitiesListModel> facilitiesListModels;
  // Models for severityCard dynamic component.
  late FlutterFlowDynamicModels<SeverityCardModel> severityCardModels;
  // Model for writingIndicator component.
  late WritingIndicatorModel writingIndicatorModel;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Backend Call - API (Chat)] action in IconButton widget.
  ApiCallResponse? agentResponse;
  // Stores action output result for [Backend Call - API (Get Nearby Facilities)] action in IconButton widget.
  ApiCallResponse? getFacilitiesApiResponse;
  // Stores action output result for [Backend Call - API (Return Function Result)] action in IconButton widget.
  ApiCallResponse? returnInvocationResponse;
  // Stores action output result for [Backend Call - API (Get Severity)] action in IconButton widget.
  ApiCallResponse? severityAPIResponse;
  // Stores action output result for [Backend Call - API (Return Function Result)] action in IconButton widget.
  ApiCallResponse? returnInvocationResponseSevCheck;

  @override
  void initState(BuildContext context) {
    listViewController = ScrollController();
    facilitiesListModels =
        FlutterFlowDynamicModels(() => FacilitiesListModel());
    severityCardModels = FlutterFlowDynamicModels(() => SeverityCardModel());
    writingIndicatorModel = createModel(context, () => WritingIndicatorModel());
  }

  @override
  void dispose() {
    listViewController?.dispose();
    facilitiesListModels.dispose();
    severityCardModels.dispose();
    writingIndicatorModel.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
